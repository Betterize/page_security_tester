<html>
<head>
<meta property="og:url" content="https://yolo.tld/default.asp?content=expanded&search_content=results&number=<?php echo $_GET["number"]; ?>" />
</head>
</html>