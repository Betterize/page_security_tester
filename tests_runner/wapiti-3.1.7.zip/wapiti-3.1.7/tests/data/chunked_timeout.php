<?php
header("Transfer-encoding: chunked");
flush();
sleep(5);
?>