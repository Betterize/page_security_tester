<?php
header("location: ".$_GET["url"]);
echo "plop";
?>
